const mocha = require('mocha');
const should = require('should');

const API_PREFIX = '/api/v1';

module.exports = {
    mocha,
    should,
    API_PREFIX
}